#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Importing Libraries
import numpy as np
import pandas as pd

from sklearn.datasets import load_breast_cancer;

#Wisconsin Breast Cancer Dataset
cancer = load_breast_cancer();
X = cancer.data;
y = cancer.target;


# In[2]:


#Converting it into a pandas dataframe
cancer_df=pd.DataFrame(cancer.data, columns=cancer.feature_names)


# In[3]:


cancer_df.sample(5)


# In[4]:


#Adding column 'target'
cancer_df['Target'] = y


# In[6]:


#Assigning Tumor name to target values
y = np.where(y=='0', 'Malignant', y)
y = np.where(y=='1', 'Benign', y)


# In[7]:


#Data with tumor information
data_with_tumor = cancer_df.copy()
data_with_tumor["Target name"] = y
print(data_with_tumor.sample(5))


# In[8]:


#Statistical Information about our dataset
data_with_tumor.info()


# In[9]:


#Splitting our data into test and train
from sklearn.model_selection import train_test_split;

X_train , X_test, y_train, y_test = train_test_split(X,
                                                     y,
                                                     test_size = 0.2,
                                                     random_state = 0);

print(X_train.shape);
print(y_train.shape);
print("\r\n");
print(X_test.shape);
print(y_test.shape);


# # Decision Tree Classifier

# In[10]:


#Information Gain on decision tree
from sklearn.tree import DecisionTreeClassifier;

tree = DecisionTreeClassifier(criterion    =  'entropy',
                              max_depth    =  3,
                              random_state =  0 );
tree_model=tree.fit(X_train, y_train)


# In[11]:


#Plot the tree
from sklearn.tree import plot_tree;

plot_tree(tree,
          feature_names = cancer.feature_names,
          fontsize      = 7 )


# ### Performance Measures For Decision Tree Classifier

# In[12]:


#Accuracy Score
from sklearn.metrics import accuracy_score;
y_pred_train = tree.predict(X_train);
print("Train Set Accuracy : ", accuracy_score(y_train, y_pred_train))
y_pred_test = tree.predict(X_test);
print("Test Set Accuracy  : ", accuracy_score(y_test, y_pred_test))


# In[13]:


#Prediction
Test_point = [[17.99, 10.38, 122.80, 1001.0, 0.11840,0.27760, 0.3001, 0.14710
               
,0.2419,0.07871,1.095
,0.9053
,8.589
,153.4
,0.006399
,0.04904
,0.05373
,0.01587
,0.03003
,0.006193
,25.38
,17.33
,184.60, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.11890]]

print(tree.predict(Test_point))


# In[17]:


#Classification Report
import sklearn
print("Training metrics:")
print(sklearn.metrics.classification_report(y_true= y_train, y_pred= y_pred_train))
    
# test data metrics
print("Test data metrics:")
print(sklearn.metrics.classification_report(y_true= y_test, y_pred= y_pred_test))

score=tree.score(X_test, y_pred_test)
print("score=", score)


# # Random Forest Classifier

# In[18]:


from sklearn.ensemble import RandomForestClassifier


# In[21]:


rf = RandomForestClassifier()

rf.fit(X_train,y_train)

# Predictions on training and validation
y_pred_trainrf = rf.predict(X_train)

# predictions for test
y_pred_testrf = rf.predict(X_test)

#train metrics
print("Training metrics:")
print(sklearn.metrics.classification_report(y_true= y_train, y_pred= y_pred_trainrf))
    
#test metrics
print("Test data metrics:")
print(sklearn.metrics.classification_report(y_true= y_test, y_pred= y_pred_testrf))

print("Train Set Accuracy : ", accuracy_score(y_train, y_pred_trainrf))
print("Test Set Accuracy : ", accuracy_score(y_test, y_pred_testrf))

score_rf=rf.score(X_test, y_pred_testrf)

print("score=",score)


# In[33]:


Test_point = [[17.99, 10.38, 122.80, 1001.0, 0.11840,0.27760  ,  0.3001 ,   0.14710 ,0.2419,0.07871,1.095
,0.9053
,8.589
,153.4
,0.006399
,0.04904
,0.05373
,0.01587
,0.03003
,0.006193
,25.38
,17.33
,184.60, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.11890]]

print(rf.predict(Test_point))


# # K-Nearest Neighbor Classifier

# In[22]:


#New KNN model
from sklearn.neighbors import KNeighborsClassifier

#Just putting 5 for now
knn = KNeighborsClassifier(n_neighbors=5)

knn.fit(X_train, y_train)


# In[25]:


#Feature metrics
y_pred_trainknn = knn.predict(X_train)

# predictions for test
y_pred_testknn = knn.predict(X_test)

# train metrics
print("Training metrics:")
print(sklearn.metrics.classification_report(y_true= y_train, y_pred= y_pred_trainknn))
    
# test metrics
print("Test data metrics:")
print(sklearn.metrics.classification_report(y_true= y_test, y_pred= y_pred_testknn))

print("Train Set Accuracy : ", accuracy_score(y_train, y_pred_trainknn))
print("Test Set Accuracy : ", accuracy_score(y_test, y_pred_testknn))

score_knn=knn.score(X_test, y_pred_testknn)
print("Score= ",score_knn)


# In[34]:


Test_point = [[17.99, 10.38, 122.80, 1001.0, 0.11840,0.27760  ,  0.3001 ,   0.14710 ,0.2419,0.07871,1.095
,0.9053
,8.589
,153.4
,0.006399
,0.04904
,0.05373
,0.01587
,0.03003
,0.006193
,25.38
,17.33
,184.60, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.11890]]

print(knn.predict(Test_point))


# ### Feature Selection and Hypertuning the Parameters using GridSearchCV

# In[26]:


#Selecting cross value score for 5 fold cross validation
from sklearn.model_selection import cross_val_score
import numpy as np
#New KNN model
knn_cv = KNeighborsClassifier(n_neighbors=3)
#train model with cv score=5 
cv_scores = cross_val_score(knn_cv, X, y, cv=5)
#print each cv score (accuracy) and average them
print(cv_scores)
print("Cross Value Score Mean:{}".format(np.mean(cv_scores)))


# In[27]:


#GridSearch
from sklearn.model_selection import GridSearchCV
#New KNN model
knn2 = KNeighborsClassifier()
#create a dictionary of all values we want to test for n_neighbors
param_grid = {"n_neighbors": np.arange(1, 31)}
#use gridsearch to test all values for n_neighbors
knn_gscv = GridSearchCV(knn2, param_grid, cv=5)
#fit model to data
knn_gscv.fit(X, y)


# In[29]:


knn_gscv.best_params_


# In[30]:


knn_gscv.best_score_


# In[31]:


#Feature Selection
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
knn_fs = KNeighborsClassifier(n_neighbors=14) # ml_algo used = knn
sfs1 = SFS(knn_fs, 
           k_features=3, 
           forward=True, # if forward = True then SFS otherwise SBS
           floating=False, 
           verbose=2,
           scoring='accuracy'
           )


# In[32]:


sfs1.fit(X_train, y_train)
sfs1.k_feature_names_ 


# ##### The above features are the best features that will give us the most accurate model prediction

# # Reports and Analytics

# In[45]:


import seaborn as sns
import matplotlib.pyplot as plt

plt.scatter(x=cancer_df['mean compactness'],y=cancer_df['mean concavity'], color='purple')
plt.show()

sns.set_style('darkgrid')
sns.FacetGrid(data_with_tumor,palette="rocket_r", hue = 'Target name')    .map(plt.scatter, 'mean compactness','mean concavity')    .add_legend()

plt.show()


# ### We can see that the mean concavity and the mean compactness of the breasts are low when there is no significant sign of breast cancer risk whereas in Malignant the same features are more by value.

# In[37]:



sns.set_style('darkgrid')
sns.FacetGrid(data_with_tumor,palette="rocket_r", hue = 'Target name')    .map(plt.scatter, 'mean area','mean perimeter')    .add_legend()

plt.show()


# ### We can see that mean area and perimeter are small for women who do not have much risk of breast cancer.

# In[40]:



sns.set_style('darkgrid')
sns.FacetGrid(data_with_tumor,palette="winter_r", hue = 'Target name')    .map(plt.scatter, 'mean radius','worst radius')    .add_legend()

plt.show()


# ### We can see that the mean radius vs worst radius is more for women prone to breast cancer.

# # Table for final algorithm selection upon metrics comparison

# In[48]:


from sklearn.metrics import make_scorer
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.model_selection import cross_validate

scoring = {'accuracy':make_scorer(accuracy_score), 
           'precision':make_scorer(precision_score),
           'recall':make_scorer(recall_score), 
           'f1_score':make_scorer(f1_score)}

def models_evaluation(X, y, folds):
   
    # Perform cross-validation
    dtr = cross_validate(tree, X, y, cv=folds, scoring=scoring)
    rfc = cross_validate(rf, X, y, cv=folds, scoring=scoring)
    kncsq = cross_validate(knn, X, y, cv=folds, scoring=scoring)

    # Create a data frame with the models performance metrics scores
    models_scores_table = pd.DataFrame({'Decision Tree':[dtr['test_accuracy'].mean(),
                                                               dtr['test_precision'].mean(),
                                                               dtr['test_recall'].mean(),
                                                               dtr['test_f1_score'].mean()],
                                       
                                      'Random Forest Classifier':[rfc['test_accuracy'].mean(),
                                                                   rfc['test_precision'].mean(),
                                                                   rfc['test_recall'].mean(),
                                                                   rfc['test_f1_score'].mean()],
                                       
                                      'K-Nearest Neighbors':[kncsq['test_accuracy'].mean(),
                                                       kncsq['test_precision'].mean(),
                                                       kncsq['test_recall'].mean(),
                                                       kncsq['test_f1_score'].mean()]},
                                      
                                      index=['Accuracy', 'Precision', 'Recall', 'F1 Score'])
    
    # Add 'Best Score' column
    models_scores_table['Best Score'] = models_scores_table.idxmax(axis=1)
    
    # Return models performance metrics scores data frame
    return(models_scores_table)
  
# Run models_evaluation function with 5 cross folds
models_evaluation(cancer.data, cancer.target, 5)

